#include <stdio.h>

int main(void) {
    int n;
    scanf("%d", &n);

    int middle = n / 2;

    for (int row = 0; row < n; row++) {
        int wing;

        if (row <= middle) {
            wing = row + 1;
        } else {
            wing = n - row;
        }

        int gap = 2 * (n - wing) - 1;

        for (int i = 0; i < wing; i++) {
            printf("*");
        }

        for (int i = 0; i < gap; i++) {
            printf(" ");
        }

        for (int i = 0; i < wing; i++) {
            printf("*");
        }

        printf("\n");
    }

    return 0;
}
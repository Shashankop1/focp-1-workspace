#include <stdio.h>

int main(void) {
    int n;
    scanf("%d", &n);

    // Upper half
    for (int row = 1; row <= n; row++) {
        for (int i = 0; i < n - row; i++) {
            printf(" ");
        }

        for (int i = 0; i < 2 * row - 1; i++) {
            printf("*");
        }

        printf("\n");
    }

    // Lower half
    for (int row = n - 1; row >= 1; row--) {
        for (int i = 0; i < n - row; i++) {
            printf(" ");
        }

        for (int i = 0; i < 2 * row - 1; i++) {
            printf("*");
        }

        printf("\n");
    }

    return 0;
}
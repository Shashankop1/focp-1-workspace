#include <stdio.h>

int main(void) {
    int n;
    int value = 1;

    scanf("%d", &n);

    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= i; j++) {
            printf("%d", value++);

            if (j < i) {
                printf(" ");
            }
        }
        printf("\n");
    }

    return 0;
}